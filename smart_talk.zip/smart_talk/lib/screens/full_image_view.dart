import 'package:flutter/material.dart';
import 'package:photo_view/photo_view.dart';

class FullImageView extends StatelessWidget {
  final String url;
  const FullImageView({Key? key, required this.url}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          SizedBox(height: 20,),
          Center(
            child: PhotoView(
              imageProvider: NetworkImage(url),
            ),
          ),
          Positioned(
            top: 50.0,
            right: 20.0,
            child: IconButton(
              icon: Icon(Icons.close, color: Colors.white, size: 30.0),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
          ),
        ],
      ),

    );
  }
}
